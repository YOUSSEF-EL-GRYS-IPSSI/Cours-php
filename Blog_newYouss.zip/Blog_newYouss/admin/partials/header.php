<header class="row mb-3 main-header">
	<div class="col py-4 text-center">
		<a href="index.php"><b>Administration - Mon premier blog !</b></a>
	</div>
</header>