<footer class="row mt-3">
	<div class="col py-2 text-right">
		<b>Footer du site</b>
	</div>
</footer>