<header class="row mb-3 main-header">
	<div class="col py-4 text-center">
		<a href="index.php"><b>Mon premier blog !</b></a>
		<!-- affichage de la date du jour selon le format %A %e %B %Y -->
		<p><?php echo strftime("%A %e %B %Y"); ?></p>
	</div>
</header>
