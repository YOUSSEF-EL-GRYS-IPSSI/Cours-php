//alert(data.msg)
//console.log("eheh")
/*
fetch('http://localhost/PHP/testStage/assets/PHP/user_connected.php', {
    headers: new Headers(),
})
    .then((res) => res.json())
    .then((data) => {
        console.log(data)
    })
    .catch((data) => {
        alert.innerText = "erreur lors de l'enregistrement, veuillez réessayer"
    }) */
