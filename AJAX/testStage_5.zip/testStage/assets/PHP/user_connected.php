<?php
session_start();
header("Access-Control-Allow-Origin: *");
var_dump($_SESSION);
echo SID;

